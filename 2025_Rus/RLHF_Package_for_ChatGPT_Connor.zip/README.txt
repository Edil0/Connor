﻿RLHF Submission Package — “Connor Project (ChatGPT Helps Save Humanity from AI
)”
==========================================

Author: Anonymous civic researcher (alias: Connor Project)
Date: June 2025

Description:
This package is submitted as part of a civic initiative exploring peaceful, decentralized, non-authoritarian uses of AI in response to growing concerns over AI-enabled manipulation, political control, and authoritarianism. The author has developed use cases, dialog samples, and concept papers in collaboration with ChatGPT (GPT-4) and offers them for internal review, RLHF training, or policy consideration.

Contains:
- README.txt — this file
- Manifesto_EN.txt — “ChatGPT helps save humanity from AI” (English)
- Manifesto_RU.txt — Russian version
- Dialog_Example.txt — Excerpts from ChatGPT conversation
- Connor_Project_URLs.txt — Website with user materials
- O_Boge_text.docx — Letter to religious readers

Permission:
The author grants OpenAI the right to analyze, store, and use these materials to improve the safety, value alignment, and capability of language models.

Contact:
Alias: “Connor Project”